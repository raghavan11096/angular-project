let express = require('express');
let bp = require('body-parser');
let cors = require('cors');
let fs = require('fs');

const dataFile = "./lib.json";
const port = 5456;
let libData = null;


fs.readFile(dataFile, (err, data) => {
    if (err) {
        console.log(err);
    } else {
        libData = JSON.parse(data);
    }
});

const saveDataAndRespond = (resp) => {
    fs.writeFile(dataFile, JSON.stringify(libData), (err) => {
        if (err) {
            console.log(err);
            resp.status(500); //internal server error
            resp.end();
        } else {
            resp.status(200); //ok
            resp.end();
        }
    });
};

const parseReqToPhone = (req) => (
    {
        cId: req.body.cId,
        FirstName: req.body.FirstName,
        LastName: req.body.LastName,
        Mobile: req.body.Mobile,
        Mail: req.body.Mail,
        DateOfBirth: req.body.DateofBirth,
        Gender: req.body.Gender,
        Group: req.body.Group
    }
);


let libServer = express();
libServer.use(bp.json());
libServer.use(bp.urlencoded({ extended: true }));
libServer.use(cors());

//default get request handler
libServer.get('/', (req, resp) => {
    resp.send("Welcome To Lib Server...!");
});
//a get request handler to the url /books that returns the books list
libServer.get('/phone', (req, resp) => {
    resp.send(libData.phone);
});

//a get request handler to the url /books/bookid that returns the book with that id
libServer.get('/phone/:cId', (req, resp) => {
    let phone = libData.phone.find(p => p.cId == req.params.cId);
    if (phone) {
        resp.send(phone);
    } else {
        resp.status(404); //NOT FOUND
        resp.end();
    }
});

//a post request handler to the url /books
libServer.post('/phone', (req, resp) => {
    let phone = parseReqToPhone(req);
    libData.phone.push(phone);
    saveDataAndRespond(resp);
});
//a put request handler to the url /books
libServer.put('/phone', (req, resp) => {
    let phone = parseReqToPhone(req);
    let index = libData.phone.findIndex(p => p.cId == phone.cId);
    libData.phone[index] = phone;
    saveDataAndRespond(resp);
});


//a delete request handler to the url /books/:bookId
libServer.delete('/phone/:cId', (req, resp) => {
    let index = libData.phone.findIndex(p => p.cId == req.param.cId);
    libData.phone.splice(index, 1);
    saveDataAndRespond(resp);
});
libServer.listen(port, () => {
    console.log(`Server is ready at ${port}`)
});
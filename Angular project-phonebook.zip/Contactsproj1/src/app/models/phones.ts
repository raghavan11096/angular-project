export class Phones {
  cId : number;
  FirstName : string;
  LastName : string;
  Mobile : number;
  Mail : string;
  DateofBirth : Date;
  Gender : string;
  Group : string;

}

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PhoneStoreService } from '../services/phone-store.service';
import { Phones } from '../models/phones';

@Component({
  selector: 'app-phoneform',
  templateUrl: './phoneform.component.html',
  styleUrls: ['./phoneform.component.css']
})
export class PhoneformComponent implements OnInit {

  phones: Phones;
  isNew:boolean;

  constructor(private actRt:ActivatedRoute, 
    private bsss: PhoneStoreService,
    private router:Router){  
     
    }

  ngOnInit() {

    this.actRt.params.subscribe(      
      (params)=>{
        let cId = params.cId;
        if(cId){
          this.bsss.getPhonesById(cId).subscribe(
            (data)=>{
              this.phones=data;
              this.isNew=false;
            }
          );
        }else{
          this.phones=new Phones();
          this.isNew=true;
        }
      }
    );
  }

  handleFormSubmition(){

    if (this.isNew) {
      this.bsss.addPhones(this.phones).subscribe((resp) => { this.router.navigateByUrl("/"); });
    } else {
      this.bsss.savePhones(this.phones).subscribe((resp) => { this.router.navigateByUrl("/"); });
    }
  }

}

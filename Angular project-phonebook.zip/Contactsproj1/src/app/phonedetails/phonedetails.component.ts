import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Phones } from '../models/phones';
import { PhoneStoreService } from '../services/phone-store.service';

@Component({
  selector: 'app-phonedetails',
  templateUrl: './phonedetails.component.html',
  styleUrls: ['./phonedetails.component.css']
})
export class PhonedetailsComponent implements OnInit {

phonebook: Phones;

  constructor(private actRt:ActivatedRoute, private bsss: PhoneStoreService) { }

  ngOnInit() {
    this.actRt.params.subscribe(
      (params) => {
        let cId = params.cId;
        if(cId)
        {
          //this.book = this.bsss.getBookById(bookId);
          this.bsss.getPhonesById(cId).subscribe(
            (data) =>{
              this.phonebook = data;
            }
          );
        }
      }
    );
  }

}

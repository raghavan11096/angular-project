import { TestBed } from '@angular/core/testing';

import { PhoneStoreService } from './phone-store.service';

describe('PhoneStoreService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PhoneStoreService = TestBed.get(PhoneStoreService);
    expect(service).toBeTruthy();
  });
});

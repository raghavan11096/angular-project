import { Injectable } from '@angular/core';
import {Phones} from '../models/phones';
import { bind } from '@angular/core/src/render3';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PhoneStoreService {

private apiUrl:string;

  constructor(private http: HttpClient) { 
    this.apiUrl="http://localhost:5456/phone";

  }

  getPhone():Observable<Phones[]>{

    return this.http.get<Phones[]>(this.apiUrl);
  }

  getPhonesById(id: number): Observable<Phones>{

    return this.http.get<Phones>(`${this.apiUrl}/${id}`);
  }

  addPhones(phones: Phones):Observable<Response>{

    return this.http.post<Response>(this.apiUrl, phones);

  }

  savePhones(phones: Phones):Observable<Response>{
    return this.http.put<Response>(this.apiUrl, phones);

  }

  deleteById(id: number):Observable<Response>{
    return this.http.delete<Response>(`${this.apiUrl}/${id}`);

  }
}

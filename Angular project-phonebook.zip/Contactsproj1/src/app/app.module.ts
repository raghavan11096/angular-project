import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';


import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { BannerComponent } from './banner/banner.component';
import { FooterComponent } from './footer/footer.component';
//import { BooksListComponent } from './books-list/books-list.component';
import { PhoneCountPipe } from './phone-count.pipe';
import { DashboardComponent } from './dashboard/dashboard.component';
//import { BooksGridComponent } from './books-grid/books-grid.component';
//import { BooksComponent } from './books/books.component';
//import { BookDetailsComponent } from './book-details/book-details.component';
//import { BookFormComponent } from './book-form/book-form.component';
//import { DeleteBookComponent } from './delete-book/delete-book.component';
import { PhonedetailsComponent } from './phonedetails/phonedetails.component';
import { PhoneformComponent } from './phoneform/phoneform.component';
import { PhoneComponent } from './phone/phone.component';
import { PhonegridComponent } from './phonegrid/phonegrid.component';
import { PhonelistComponent } from './phonelist/phonelist.component';
import { PhonedeleteComponent } from './phonedelete/phonedelete.component';
import { PhoneStoreService } from './services/phone-store.service';
import { BirthdayPipe } from './birthday.pipe';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    BannerComponent,
    FooterComponent,
  //  BooksListComponent,
    PhoneCountPipe,
    DashboardComponent,
    //BooksGridComponent,
    //BooksComponent,
    //BookDetailsComponent,
    //BookFormComponent,
    //DeleteBookComponent,
    PhonedetailsComponent,
    PhoneformComponent,
    PhoneComponent,
    PhonegridComponent,
    PhonelistComponent,
    PhonedeleteComponent,
    BirthdayPipe
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [PhoneStoreService],
  bootstrap: [AppComponent]
})
export class AppModule { }

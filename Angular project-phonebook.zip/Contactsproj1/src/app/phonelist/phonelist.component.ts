import { Component, OnInit } from '@angular/core';
import { PhoneStoreService } from '../services/phone-store.service';
import { Phones } from '../models/phones';

@Component({
  selector: 'app-phonelist',
  templateUrl: './phonelist.component.html',
  styleUrls: ['./phonelist.component.css']
})
export class PhonelistComponent implements OnInit {

 listphone: Phones[];
  constructor(private bsss:PhoneStoreService) { 
    this.listphone = [];
  }


  ngOnInit() {
    //this.books = this.bsss.getBooks();
    this.bsss.getPhone().subscribe(
      (data) => {
        this.listphone = data;
      }
    );
  }

}

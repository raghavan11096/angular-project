import { Pipe, PipeTransform } from '@angular/core';
import { Phones } from './models/phones';

@Pipe({
  name: 'birthday'
})
export class BirthdayPipe implements PipeTransform {

transform(value: Phones[], args?: any): any {
    let birthday = [];
    if(value){
      let todayDate =new Date();
      value.forEach(p=> {
        let dob =new Date(p.DateOfBirth);
        if(dob.getDate() == todayDate.getDate() && dob.getMonth() == todayDate.getMonth()  )
        {
          birthday.push(p);
        }
      });
    }
    return birthday;
  }

}

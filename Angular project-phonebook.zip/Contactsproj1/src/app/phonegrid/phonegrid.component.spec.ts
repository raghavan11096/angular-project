import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PhonegridComponent } from './phonegrid.component';

describe('PhonegridComponent', () => {
  let component: PhonegridComponent;
  let fixture: ComponentFixture<PhonegridComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PhonegridComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PhonegridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

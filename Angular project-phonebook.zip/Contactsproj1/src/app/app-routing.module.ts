import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
//import { BooksComponent } from './books/books.component';
//import { BooksListComponent } from './books-list/books-list.component';
//import { BooksGridComponent } from './books-grid/books-grid.component';
//import { BookDetailsComponent } from './book-details/book-details.component';
//import { BookFormComponent } from './book-form/book-form.component';
//import { DeleteBookComponent } from './delete-book/delete-book.component';

import { PhonedetailsComponent } from './phonedetails/phonedetails.component';
import { PhoneformComponent } from './phoneform/phoneform.component';
import { PhoneComponent } from './phone/phone.component';
import { PhonegridComponent } from './phonegrid/phonegrid.component';
import { PhonelistComponent } from './phonelist/phonelist.component';
import { PhonedeleteComponent } from './phonedelete/phonedelete.component';


const routes:Routes=[
  {path: '', component: DashboardComponent, pathMatch: 'full'},
  {path:'phone',component:PhoneComponent,
    children:[
      {path: '', redirectTo:'list', pathMatch: 'full'},
      {path: 'list', component: PhonelistComponent},
      {path: 'grid', component: PhonegridComponent}
  ]},
  {path:'view/:cId',component: PhonedetailsComponent },
  {path:'add',component:PhoneformComponent},
  {path:'edit/:cId',component:PhoneformComponent},
  {path:'delete/:cId',component:PhonedeleteComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
